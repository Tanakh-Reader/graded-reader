export const COLORS = {

    // Text highlight colors
    POWDER_BLUE: '#B0E0E6',
    LIGHT_CORAL: '#F08080',
    LIGHT_GOLDENROD_YELLOW: '#FAFAD2',
    PALE_GREEN: '#98FB98',
    THISTLE: '#D8BFD8',
    LIGHT_SALMON: '#FFA07A',
}